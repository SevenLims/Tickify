'use client';
import React, { useState, useEffect } from 'react';
import TicketCard from '@/components/cards/TicketCard';
import { useGlobalState } from 'store';
import { useVoucherContext } from '@/context/VoucherContext';
import { useRouter } from 'next/navigation';
import { mintsByUser } from '@/Blockchain'; // Import mintsByUser function

const Games = () => {
  const [myTickets] = useGlobalState('myTickets');
  const [spinning, setSpinning] = useState(false);
  const [spinnerResult, setSpinnerResult] = useState<string | null>(null);
  const [spinsLeft, setSpinsLeft] = useState<number>(0); // State for spins left
  const { setVouchers } = useVoucherContext(); // Access the context
  const router = useRouter();
  
  const outcomes = [
    { text: 'RM100 Voucher!', degree: 0 },
    { text: 'RM50 Voucher!', degree: 36 },
    { text: 'RM10 Voucher!', degree: 72 },
    { text: 'Almost!', degree: 108 },
    { text: 'Almost!', degree: 144 },
    { text: 'Almost!', degree: 180 },
    { text: 'Almost!', degree: 216 },
    { text: 'Almost!', degree: 252 },
    { text: 'Almost!', degree: 288 },
    { text: 'Almost!', degree: 324 },
  ];

  // Initialize spins left from local storage or default to 0
  useEffect(() => {
    const storedSpins = localStorage.getItem('spinsLeft');
    setSpinsLeft(storedSpins ? parseInt(storedSpins) : 0);
  }, []);

  // Save spins left to local storage whenever it changes
  useEffect(() => {
    localStorage.setItem('spinsLeft', spinsLeft.toString());
  }, [spinsLeft]);

  // Calculate spins left based on unminted tickets
  const calculateSpinsLeft = async () => {
    const mintedTickets = await mintsByUser(); // Get the minted tickets
    const unmintedTickets = myTickets.filter((ticket: any) =>
      !mintedTickets.some((mintedTicket: any) => mintedTicket.ticket_id === ticket.ticket.ticketId)
    );
    return unmintedTickets.length;
  };

  // Update spins left whenever myTickets change
  useEffect(() => {
    const updateSpinsLeft = async () => {
      const spins = await calculateSpinsLeft();
      setSpinsLeft(spins);
    };

    updateSpinsLeft();
  }, [myTickets]);

  const handlePlay = () => {
    if (spinning || spinsLeft <= 0) return; // Prevent spinning if no spins left

    // Show confirmation dialog
    const isConfirmed = window.confirm("Are you sure you want to play?");
    if (!isConfirmed) return; // Exit if the user does not confirm

    setSpinning(true);
    setSpinsLeft(spinsLeft - 1); // Decrement spins left

    const randomIndex = Math.floor(Math.random() * outcomes.length);
    const selectedOutcome = outcomes[randomIndex];
    const spinDegree = 360 * 5 + selectedOutcome.degree;

    const wheelElement = document.querySelector('.spinner-wheel');
    if (wheelElement) {
      wheelElement.classList.add('spin');
      (wheelElement as HTMLElement).style.transform = `rotate(${spinDegree}deg)`;
      setTimeout(() => {
        wheelElement?.classList.remove('spin');
      }, 5000); // Time should match the animation duration
    }

    setTimeout(() => {
      setSpinnerResult(selectedOutcome.text);
      setSpinning(false);

      // If the result is a cash voucher, issue a virtual voucher
      if (selectedOutcome.text.includes('Voucher')) {
        setVouchers((prevVouchers) => [...prevVouchers, { text: selectedOutcome.text }]);
        // Redirect to Reward page
        router.push('/Reward');
      }
    }, 5000);
  };

  return (
    <div className="py-24 sm:py-28 max-w-4xl mx-auto text-gray-50">
      <div className="pb-12 sm:pb-14 text-black">
        <h2 className="font-semibold text-2xl text-center">Lottery</h2>
      </div>
      <div className="mx-4 grid grid-cols-1 gap-2 sm:grid-cols-2 sm:gap-4">
        {myTickets.length > 0 ? (
          myTickets.map((item: { ticket: any }, i: number) => {
            const { category, eventDate, eventVenue, eventId, eventTitle, ticketId, ticketPrice } = item?.ticket;
            return (
              <div key={i + 1}>
                <TicketCard
                  category={category}
                  eventDate={eventDate}
                  eventVenue={eventVenue}
                  eventId={eventId}
                  eventTitle={eventTitle}
                  ticketId={ticketId}
                  ticketPrice={ticketPrice}
                  completed={false}
                  owner={''}
                />
                  <button
                  onClick={handlePlay}
                  className={`mt-4 py-2 px-4 rounded w-full ${
                    spinsLeft <= 0 ? 'bg-gray-500 cursor-not-allowed' : 'bg-blue-500'
                  } text-white`}
                  disabled={spinning || spinsLeft <= 0}
                >
                  {spinning ? 'Spinning...' : `Play (Spins Left: ${spinsLeft})`}
                </button>
              </div>
            );
          })
        ) : (
          <p className="font-bold text-center pt-5 text-black">
            You need non-minted tickets to participate...
          </p>
        )}
      </div>

      {spinnerResult && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-75">
          <div className="bg-black p-6 rounded-lg text-center">
            <p className="text-xl font-bold">{spinnerResult}</p>
            <button
              onClick={() => setSpinnerResult(null)}
              className="mt-4 bg-blue-500 text-white py-2 px-4 rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}

      <div className="spinner-container">
        <div className="spinner-wheel">
          {outcomes.map((outcome, i) => (
            <div key={i} className="segment" />
          ))}
        </div>
        <div className="spinner-pointer"></div>
      </div>
    </div>
  );
};

export default Games;
