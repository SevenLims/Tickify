import React from 'react'
import { AiFillLinkedin } from 'react-icons/ai';
import { useState } from 'react';
import { ethers } from 'ethers';

const About = () => {
  return (
    <div className='py-24 sm:py-28 max-w-5xl mx-auto text-black'>
      <div className='mx-4'>
        
        <div className='text-center mb-10'>
          <h2 className='font-black text-4xl'>Tickify</h2>
          <p className='mt-4 text-lg'>
          Tickify provides secure, decentralized ticket transactions, removing intermediaries, ensuring data privacy, reducing fraud, and streamlining ticketing. Key features include:
          </p>
        </div>
        
        <div className='grid grid-cols-1 lg:grid-cols-3 gap-6'>
          <div className='rounded-lg p-6 bg-[#f3f4f6] shadow-lg'>
            <div className='flex items-center justify-center mb-4'>
              <h1 className='bg-[#4a90e2] text-white w-12 h-12 flex items-center justify-center rounded-full text-2xl font-bold shadow-md'>1</h1>
            </div>
            <p className='text-center'>
            Discover and attend events of all sizes from diverse communities, tailored to your interests.
            </p>
          </div>
          
          <div className='rounded-lg p-6 bg-[#e6e9f0] shadow-lg'>
            <div className='flex items-center justify-center mb-4'>
              <h1 className='bg-[#2ecc71] text-white w-12 h-12 flex items-center justify-center rounded-full text-2xl font-bold shadow-md'>2</h1>
            </div>
            <p className='text-center'>
            To ensure ticket authenticity and eliminate fraud by implementing a qr code verification mechanism that prevents the existence of fake tickets.
            </p>
          </div>
          
          <div className='rounded-lg p-6 bg-[#d1e3f8] shadow-lg'>
            <div className='flex items-center justify-center mb-4'>
              <h1 className='bg-[#e74c3c] text-white w-12 h-12 flex items-center justify-center rounded-full text-2xl font-bold shadow-md'>3</h1>
            </div>
            <p className='text-center'>
            To enhance accessibility by offering virtual pre-event workshops, allowing students to participate without the need for long-distance travel.
            </p>
          </div>
        </div>
        
        {/* Uncomment the following block if you want to add the LinkedIn link back */}
        {/* <div className='flex py-6 justify-center items-center text-sm'>
          <a href="https://www.linkedin.com/in/han-chung-lim-402833238/" target='_blank'>
            <h2 className='flex items-center cursor-pointer'>
              Developed by: Muhindo Galien 
              <AiFillLinkedin className='ml-2 text-xl font-bold text-black'/>
            </h2>
          </a>
        </div> */}
        
      </div>
    </div>
  )
}

export default About

