import React from 'react';
import QRCode from 'react-qr-code';
import { useVoucherContext } from '@/context/VoucherContext';
import { useRouter } from 'next/navigation';

const Reward = () => {
  const { vouchers } = useVoucherContext();
  const router = useRouter();

  // Function to generate custom QR code message based on voucher text
  const getQRCodeValue = (text: string) => {
    if (text.includes('RM100 Voucher!')) {
      return 'It is a real ticket! Redeem it on event day!';
    }
    if (text.includes('RM50 Voucher!')) {
      return 'It is a real ticket! Redeem it on event day!';
    }
    if (text.includes('RM10 Voucher!')) {
      return 'It is a real ticket! Redeem it on event day!';
    }
    return 'Voucher verified, redeem it on event day!';
  };

  return (
    <div className="py-24 sm:py-28 max-w-4xl mx-auto text-gray-50">
      <div className="pb-12 sm:pb-14 text-black">
        <h2 className="font-semibold text-2xl text-center">My Vouchers</h2>
      </div>
      <div className="mx-4 grid grid-cols-1 gap-2 sm:grid-cols-2 sm:gap-4">
        {vouchers.length > 0 ? (
          vouchers.map((voucher, i) => (
            <div key={i} className="bg-black p-4 rounded shadow">
              <p className="text-lg font-semibold">{voucher.text}</p>
              <div className="mt-4">
                {voucher.text.includes('Voucher') && (
                  <QRCode 
                    value={getQRCodeValue(voucher.text)} 
                    size={64} 
                    bgColor="#87a5ffe0" 
                    fgColor="#000000" 
                  />
                )}
              </div>
            </div>
          ))
        ) : (
          <p className="font-bold text-center pt-5 text-black">
            No vouchers available.
          </p>
        )}
      </div>
      <button
        onClick={() => router.push('/Games')}
        className="mt-4 bg-blue-500 text-white py-2 px-4 rounded w-full"
      >
        Back to Games
      </button>
    </div>
  );
};

export default Reward;
