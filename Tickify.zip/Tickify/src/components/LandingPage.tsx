'use client';
import React, { useReducer } from 'react';
import Hero from './Hero';
import { useGlobalState } from 'store';
import Events from './AllEvents';

const LandingPage = () => {
  const [connectedAccount] = useGlobalState('connectedAccount');

  return (
    <div className='py-24 sm:py-28 max-w-4xl mx-auto'>
      <Hero />
      <hr className='border-2 border-black my-6' /> 
      <div className='pb-10 sm:pb-10 text-black'>
        {connectedAccount ? (
          <h2 className='font-semibold mx-4 pt-6 sm:mx-6 lg:mx-0 text-xl sm:text-2xl text-center sm:text-left'>
            Latest events
          </h2>
        ) : (
          <p className='w-10/12 sm:w-4/12 mx-auto font-bold text-center p-5 bg-[#87a5ffe0] shadow-md rounded cursor-pointer hover:bg-blue-600'>
            Connect your wallet with MetaMask!
          </p>
        )}
      </div>
      {connectedAccount.length > 0 ? (
        <div className='sm:mx-6 lg:mx-0'>
          <div className='h-80 overflow-y-auto'>
            <Events />
          </div>
        </div>
      ) : null}
      <hr className='border-2 border-black my-6' /> 
    </div>
  );
};

export default LandingPage;
