import React from 'react'

const Footer = () => {
  const date = new Date().getFullYear();
  return (
    <div className='max-w-4xl mx-auto pt-4 sm:mb-8 h-20 sm:h-0 text-black font-medium'>
      <div className="flex justify-center items-center h-full">
        <h2 className='text-center'>
          
        </h2>
      </div>
    </div>
  )
}

export default Footer
