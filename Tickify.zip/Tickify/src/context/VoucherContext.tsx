// src/context/VoucherContext.tsx
'use client';
import React, { createContext, useState, useContext, ReactNode } from 'react';

interface VoucherContextType {
  vouchers: Array<{ text: string }>;
  setVouchers: React.Dispatch<React.SetStateAction<Array<{ text: string }>>>;
}

const VoucherContext = createContext<VoucherContextType | undefined>(undefined);

export const VoucherProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [vouchers, setVouchers] = useState<Array<{ text: string }>>([]);

  return (
    <VoucherContext.Provider value={{ vouchers, setVouchers }}>
      {children}
    </VoucherContext.Provider>
  );
};

export const useVoucherContext = () => {
  const context = useContext(VoucherContext);
  if (context === undefined) {
    throw new Error('useVoucherContext must be used within a VoucherProvider');
  }
  return context;
};
